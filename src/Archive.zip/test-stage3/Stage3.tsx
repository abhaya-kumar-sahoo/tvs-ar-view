import { useEffect } from "react";
import * as THREE from "three";
import Video1 from "../assets/videos/eg1.mp4";
import Video2 from "../assets/videos/eg2.mp4";
import Text3D from "./Text3D";
import VideoPlane from "./3dVideo";
import GLBModel from "./GLBModel";
import createARButton from "./StartButton";

export default function App() {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera();
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });

  useEffect(() => {
    //abhaya kumar sahoo

    renderer.setSize(0, 0);
    renderer.xr.enabled = true;
    document.body.appendChild(renderer.domElement);

    // document.body.appendChild(
    //   ARButton.createButton(renderer, { requiredFeatures: ["hit-test"] })
    // );

    // Custom AR Button
    document.body.appendChild(
      createARButton(renderer, { requiredFeatures: ["hit-test"] })
    );

    // Lighting
    addLights(scene);

    Text3D(scene, "TVS Pulser");
    VideoPlane(Video1, scene, renderer, [-1.2, 0.6, -2]);
    VideoPlane(Video2, scene, renderer, [1.2, 0.6, -2]);
    GLBModel(scene, "/model.glb", [-1, -0.5, -2]);
    // GLBModel(scene, "/engine.glb", [-1, -0.5, -3]);

    // Render loop
    renderer.setAnimationLoop(() => {
      renderer.render(scene, camera);
    });

    // Cleanup
    return () => {
      renderer.setAnimationLoop(null);
      document.body.removeChild(renderer.domElement);
    };
  }, []);

  return null;
}

function addLights(scene) {
  const light = new THREE.HemisphereLight(0xffffff, 0xbbbbff, 1);
  light.position.set(0.5, 1, 0.25);
  scene.add(light);

  // 1. Hemisphere light (already included)
  const hemiLight = new THREE.HemisphereLight(0xffffff, 0xffffff, 1.2);
  hemiLight.position.set(0, 20, 0);
  scene.add(hemiLight);

  // 2. Directional light (like sunlight)
  const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
  dirLight.position.set(3, 10, 5);
  dirLight.castShadow = true;
  scene.add(dirLight);

  // 3. Point light (near camera or model)
  const pointLight = new THREE.PointLight(0xffffff, 1);
  pointLight.position.set(0, 2, -2); // In front of the scene
  scene.add(pointLight);

  // 4. Ambient light (fill light for softening shadows)
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
  scene.add(ambientLight);
}
